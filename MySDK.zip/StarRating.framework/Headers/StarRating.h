//
//  StarRating.h
//  StarRating
//
//  Created by Vivek Gupta on 04/04/18.
//  Copyright © 2018 Vivek Gupta. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for StarRating.
FOUNDATION_EXPORT double StarRatingVersionNumber;

//! Project version string for StarRating.
FOUNDATION_EXPORT const unsigned char StarRatingVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <StarRating/PublicHeader.h>


